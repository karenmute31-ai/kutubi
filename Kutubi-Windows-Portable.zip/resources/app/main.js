/* كتبي لسطح المكتب (ويندوز) — غلاف Electron بيشغّل نفس نسخة الويب اللايف
   تحسينات تجربة القارئ على ويندوز:
   - اختصارات قراءة: F11 ملء الشاشة، Ctrl+= / Ctrl+- / Ctrl+0 تقريب خط القراءة،
     Ctrl+F بحث داخل الصفحة، Esc رجوع من ملء الشاشة
   - حجم ومكان النافذة بيتحفظوا بين الجلسات
   - قفل نسخة واحدة: فتح التطبيق تاني بيركّز النافذة الموجودة بدل ما يفتح نسخة جديدة
   - قائمة عربية بسيطة (قارئ: ملء شاشة/تقريب، وتحديث الصفحة)
   - الكاش والأوفلاين من Service Worker بتاع الموقع نفسه شغالين جوّه Electron عادي */
const { app, BrowserWindow, Menu, globalShortcut, shell } = require("electron");
const fs = require("fs");
const path = require("path");

const APP_URL = "https://kutubi-app.vercel.app/";
const stateFile = path.join(app.getPath("userData"), "window-state.json");

function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile, "utf8")); }
  catch (e) { return { width: 1280, height: 800 }; }
}
function saveState(win) {
  try {
    const b = win.getBounds();
    fs.writeFileSync(stateFile, JSON.stringify({ width: b.width, height: b.height, x: b.x, y: b.y }));
  } catch (e) {}
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); }

let win = null;
let zoom = 0; /* مستوى تقريب الخط (Electron zoom factor) */

function applyZoom() { if (win) win.webContents.setZoomLevel(zoom); }

function buildMenu() {
  const tpl = [
    {
      label: "القارئ",
      submenu: [
        { label: "ملء الشاشة (F11)", accelerator: "F11", click: () => win && win.setFullScreen(!win.isFullScreen()) },
        { label: "تكبير الخط", accelerator: "CmdOrCtrl+=", click: () => { zoom = Math.min(zoom + 0.5, 3); applyZoom(); } },
        { label: "تصغير الخط", accelerator: "CmdOrCtrl+-", click: () => { zoom = Math.max(zoom - 0.5, -2); applyZoom(); } },
        { label: "حجم الخط الأصلي", accelerator: "CmdOrCtrl+0", click: () => { zoom = 0; applyZoom(); } },
        { type: "separator" },
        { label: "تحديث الصفحة", accelerator: "CmdOrCtrl+R", click: () => win && win.webContents.reload() },
        { label: "تحديث كامل (من غير كاش)", accelerator: "CmdOrCtrl+Shift+R", click: () => win && win.webContents.reloadIgnoringCache() }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(tpl));
}

function createWindow() {
  const st = loadState();
  win = new BrowserWindow({
    width: st.width, height: st.height, x: st.x, y: st.y,
    minWidth: 900, minHeight: 600,
    icon: path.join(__dirname, "icon.png"),
    title: "كتبي — مترجم الكتب بالمصري",
    backgroundColor: "#f7f3ec",
    autoHideMenuBar: true, /* شريط القوائم مخفي افتراضيًا زي تجربة القراية — Alt بيظهره */
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });
  win.on("close", () => saveState(win));
  win.on("closed", () => { win = null; });
  /* أي لينك خارجي (ترجمة/مصادر) يفتح في متصفح النظام مش جوّه نافذة التطبيق */
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(APP_URL)) { shell.openExternal(url); return { action: "deny" }; }
    return { action: "allow" };
  });
  win.loadURL(APP_URL);
}

app.whenReady().then(() => {
  buildMenu();
  createWindow();
  globalShortcut.register("CmdOrCtrl+F", () => {
    if (win) win.webContents.executeJavaScript(
      'const s=document.querySelector("#readerSearch, input[type=search]"); if(s){ s.focus(); }'
    ).catch(() => {});
  });
});

app.on("second-instance", () => {
  if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});
app.on("window-all-closed", () => { app.quit(); });
app.on("will-quit", () => { globalShortcut.unregisterAll(); });
